package com.catv.manager

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID

private const val APP_NAME = "CATV MANAGER"

open class CATVDatabase(context: android.content.Context) :
    SQLiteOpenHelper(context, "catv_manager.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL("""
            CREATE TABLE entities(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                operator_id TEXT NOT NULL UNIQUE
            )
        """)

        db.execSQL("""
            CREATE TABLE customers(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                service_type TEXT NOT NULL,
                name TEXT NOT NULL,
                phone TEXT NOT NULL,
                stb_id TEXT,
                customer_id TEXT,
                plan TEXT,
                actual_cost INTEGER DEFAULT 0,
                customer_price INTEGER DEFAULT 0,
                activation TEXT,
                expiry TEXT,
                status TEXT DEFAULT 'Active'
            )
        """)

        db.execSQL("""
            CREATE TABLE payments(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                method TEXT NOT NULL,
                month TEXT NOT NULL,
                payment_date TEXT NOT NULL
            )
        """)

        db.execSQL("""
            CREATE TABLE monthly_bills(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                month TEXT NOT NULL,
                bill_amount INTEGER NOT NULL,
                paid_amount INTEGER DEFAULT 0,
                UNIQUE(customer_id, month)
            )
        """)

        db.execSQL("""
            CREATE TABLE packages(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                package_name TEXT NOT NULL,
                customer_price INTEGER NOT NULL,
                actual_cost INTEGER DEFAULT 0
            )
        """)

        addSyncColumns(db)
        createSafeSyncSchema(db)
        seedLocalSyncIds(db)
    }

    private fun addSyncColumns(db: SQLiteDatabase) {
        val tables = listOf("entities", "customers", "payments", "monthly_bills", "packages")
        for (table in tables) {
            addColumnIfMissing(db, table, "sync_uuid", "TEXT")
            addColumnIfMissing(db, table, "sync_status", "TEXT NOT NULL DEFAULT 'LOCAL'")
            addColumnIfMissing(db, table, "updated_at", "TEXT")
        }
    }

    /**
     * Additive-only migration. Existing business rows and primary keys are never
     * deleted, renamed, or rewritten. SQLite runs onUpgrade in a transaction.
     */
    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        if (oldVersion < 2) {
            addSyncColumns(db)

            createSafeSyncSchema(db)
            seedLocalSyncIds(db)
        }
    }

    private fun addColumnIfMissing(
        db: SQLiteDatabase,
        table: String,
        column: String,
        definition: String
    ) {
        val exists = db.rawQuery("PRAGMA table_info($table)", null).use { cursor ->
            var found = false
            val nameIndex = cursor.getColumnIndex("name")
            while (cursor.moveToNext()) {
                if (nameIndex >= 0 && cursor.getString(nameIndex) == column) found = true
            }
            found
        }
        if (!exists) db.execSQL("ALTER TABLE $table ADD COLUMN $column $definition")
    }

    private fun createSafeSyncSchema(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS sync_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                table_name TEXT NOT NULL,
                local_row_id INTEGER NOT NULL,
                sync_uuid TEXT NOT NULL,
                operation TEXT NOT NULL DEFAULT 'UPSERT',
                state TEXT NOT NULL DEFAULT 'PENDING',
                attempt_count INTEGER NOT NULL DEFAULT 0,
                last_error TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(table_name, sync_uuid, operation)
            )
        """)
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS sync_migration_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                migration_name TEXT NOT NULL,
                completed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                details TEXT
            )
        """)
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_queue_state ON sync_queue(state, id)")
    }

    private fun seedLocalSyncIds(db: SQLiteDatabase) {
        val tables = listOf("entities", "customers", "payments", "monthly_bills", "packages")
        for (table in tables) {
            db.rawQuery("SELECT id FROM $table WHERE sync_uuid IS NULL OR sync_uuid = ''", null).use { cursor ->
                val ids = mutableListOf<Long>()
                while (cursor.moveToNext()) ids.add(cursor.getLong(0))
                ids.forEach { rowId ->
                    val uuid = UUID.randomUUID().toString()
                    val values = ContentValues().apply {
                        put("sync_uuid", uuid)
                        put("sync_status", "LOCAL")
                        put("updated_at", System.currentTimeMillis().toString())
                    }
                    db.update(table, values, "id = ?", arrayOf(rowId.toString()))
                    val queue = ContentValues().apply {
                        put("table_name", table)
                        put("local_row_id", rowId)
                        put("sync_uuid", uuid)
                        put("operation", "UPSERT")
                        put("state", "PENDING")
                    }
                    db.insertWithOnConflict("sync_queue", null, queue, SQLiteDatabase.CONFLICT_IGNORE)
                }
            }
        }
        val log = ContentValues().apply {
            put("migration_name", "safe_local_sync_v2")
            put("details", "Added sync metadata only; existing business rows retained")
        }
        db.insert("sync_migration_log", null, log)
    }

    private fun enqueueForSync(table: String, rowId: Long) {
        if (rowId <= 0) return
        val uuid = UUID.randomUUID().toString()
        val values = ContentValues().apply {
            put("sync_uuid", uuid)
            put("sync_status", "LOCAL")
            put("updated_at", System.currentTimeMillis().toString())
        }
        writableDatabase.update(table, values, "id = ?", arrayOf(rowId.toString()))
        val queue = ContentValues().apply {
            put("table_name", table)
            put("local_row_id", rowId)
            put("sync_uuid", uuid)
            put("operation", "UPSERT")
            put("state", "PENDING")
        }
        writableDatabase.insertWithOnConflict("sync_queue", null, queue, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun addEntity(name: String, operatorId: String): Boolean {
        return try {
            val values = ContentValues().apply {
                put("name", name)
                put("operator_id", operatorId)
            }
            val id = writableDatabase.insertOrThrow("entities", null, values)
            enqueueForSync("entities", id)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun entities(): List<String> {
        val result = mutableListOf<String>()

        readableDatabase.rawQuery(
            "SELECT name || ' (' || operator_id || ')' FROM entities",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result.add(cursor.getString(0))
            }
        }

        return result
    }

    fun entityId(operatorId: String): Long {
        readableDatabase.rawQuery(
            "SELECT id FROM entities WHERE operator_id=?",
            arrayOf(operatorId)
        ).use { cursor ->
            if (cursor.moveToFirst()) return cursor.getLong(0)
        }
        return -1
    }

    fun addCustomer(
        entityId: Long,
        service: String,
        name: String,
        phone: String,
        stb: String,
        customerId: String,
        plan: String,
        actualCost: Int,
        customerPrice: Int,
        activation: String,
        expiry: String
    ): Long {

        val values = ContentValues().apply {
            put("entity_id", entityId)
            put("service_type", service)
            put("name", name)
            put("phone", phone)
            put("stb_id", stb)
            put("customer_id", customerId)
            put("plan", plan)
            put("actual_cost", actualCost)
            put("customer_price", customerPrice)
            put("activation", activation)
            put("expiry", expiry)
            put("status", "Active")
        }

        val id = writableDatabase.insert("customers", null, values)
        enqueueForSync("customers", id)
        return id
    }

    fun customers(service: String): List<String> {
        val result = mutableListOf<String>()

        readableDatabase.rawQuery(
            """
            SELECT name, phone, stb_id, plan, customer_price,
                   expiry, status
            FROM customers
            WHERE service_type=?
            ORDER BY name
            """,
            arrayOf(service)
        ).use { cursor ->

            while (cursor.moveToNext()) {
                result.add(
                    """
                    ${cursor.getString(0)}
                    Phone: ${cursor.getString(1)}
                    STB/ID: ${cursor.getString(2) ?: "-"}
                    Plan: ${cursor.getString(3) ?: "-"}
                    Customer Price: ₹${cursor.getInt(4)}
                    Expiry: ${cursor.getString(5) ?: "-"}
                    Status: ${cursor.getString(6)}
                    """.trimIndent()
                )
            }
        }

        return result
    }

    fun recordPayment(
        customerId: Long,
        amount: Int,
        method: String,
        month: String,
        date: String
    ) {
        val values = ContentValues().apply {
            put("customer_id", customerId)
            put("amount", amount)
            put("method", method)
            put("month", month)
            put("payment_date", date)
        }

        val id = writableDatabase.insert("payments", null, values)
        enqueueForSync("payments", id)
    }

    fun customerCount(): Int {
        readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM customers", null
        ).use {
            if (it.moveToFirst()) return it.getInt(0)
        }
        return 0
    }

    fun totalCollection(): Int {
        readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(amount),0) FROM payments",
            null
        ).use {
            if (it.moveToFirst()) return it.getInt(0)
        }
        return 0
    }
}

class MainActivity : Activity() {

    private lateinit var database: CATVDatabase
    private lateinit var content: LinearLayout

    private var selectedService = "CABLE"
    private var selectedEntity = ""

    private val navy = Color.rgb(13, 27, 55)
    private val orange = Color.rgb(255, 145, 40)
    private val backgroundColor = Color.rgb(242, 245, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        database = CATVDatabase(this)

        showDashboard()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun card(): GradientDrawable {
        return GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.LTGRAY)
        }
    }

    private fun text(
        value: String,
        size: Float = 16f,
        color: Int = navy
    ): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
    }

    private fun button(
        value: String,
        action: () -> Unit
    ): Button {
        return Button(this).apply {
            text = value
            isAllCaps = false
            setTextColor(Color.WHITE)
            textSize = 14f

            background = GradientDrawable().apply {
                setColor(navy)
                cornerRadius = dp(12).toFloat()
            }

            setOnClickListener { action() }
        }
    }

    private fun setupPage(title: String) {

        val scroll = ScrollView(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            setBackgroundColor(backgroundColor)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))

            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(navy, Color.rgb(37, 63, 115))
            ).apply {
                cornerRadius = dp(22).toFloat()
            }
        }

        header.addView(
            text(APP_NAME, 25f, Color.WHITE).apply {
                setTypeface(null, Typeface.BOLD)
            }
        )

        header.addView(
            text(title, 15f, Color.WHITE)
        )

        root.addView(header)

        content = root

        scroll.addView(root)

        setContentView(scroll)
    }

    private fun addSection(title: String) {
        content.addView(
            text(title, 19f).apply {
                setTypeface(null, Typeface.BOLD)
            }
        )
    }

    private fun addCard(value: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = this@MainActivity.card()
        }

        card.addView(text(value, 15f))

        val params = LinearLayout.LayoutParams(
            -1, -2
        ).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        }

        content.addView(card, params)
    }

    private fun showDashboard() {

        setupPage("Cable TV & Internet Management")

        addSection("BUSINESS OVERVIEW")

        addCard(
            "Total Customers: ${database.customerCount()}"
        )

        addCard(
            "Total Collection: ₹${database.totalCollection()}"
        )

        addSection("MANAGEMENT")

        content.addView(button("Cable TV Customers") {
            selectedService = "CABLE"
            showCustomers()
        })

        content.addView(button("Internet Customers") {
            selectedService = "INTERNET"
            showCustomers()
        })

        content.addView(button("Manage Operator Entities") {
            showEntities()
        })

        content.addView(button("Add Customer") {
            showAddCustomer()
        })

        content.addView(button("Help & Support") {
            showHelp()
        })
    }

    private fun showEntities() {

        setupPage("Operator Entity Management")

        addSection("REGISTERED ENTITIES")

        val list = database.entities()

        if (list.isEmpty()) {
            addCard("No entities added.")
        } else {
            list.forEach { addCard(it) }
        }

        content.addView(button("Add New Entity") {
            addEntityDialog()
        })

        content.addView(button("Back to Dashboard") {
            showDashboard()
        })
    }

    private fun addEntityDialog() {

        val name = EditText(this).apply {
            hint = "Entity Name"
        }

        val operatorId = EditText(this).apply {
            hint = "Operator ID"
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            addView(name)
            addView(operatorId)
        }

        AlertDialog.Builder(this)
            .setTitle("Add Operator Entity")
            .setView(layout)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->

                val n = name.text.toString().trim()
                val id = operatorId.text.toString().trim()

                if (n.isNotEmpty() && id.isNotEmpty()) {

                    val success = database.addEntity(n, id)

                    Toast.makeText(
                        this,
                        if (success) "Entity saved" else "Operator ID already exists",
                        Toast.LENGTH_LONG
                    ).show()

                    showEntities()
                }
            }
            .show()
    }

    private fun showAddCustomer() {

        setupPage("Add New Customer")

        val entities = database.entities()

        if (entities.isEmpty()) {
            addCard("First add an Operator Entity.")
            content.addView(button("Add Entity") {
                showEntities()
            })
            return
        }

        val entityIdInput = EditText(this).apply {
            hint = "Operator ID"
        }

        val service = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("CABLE", "INTERNET")
            )
        }

        val name = EditText(this).apply {
            hint = "Customer Name"
        }

        val phone = EditText(this).apply {
            hint = "Mobile Number"
            inputType = 3
        }

        val stb = EditText(this).apply {
            hint = "STB ID (Cable)"
        }

        val customerId = EditText(this).apply {
            hint = "Customer ID / PPPoE Username"
        }

        val plan = EditText(this).apply {
            hint = "Package / Internet Plan"
        }

        val actualCost = EditText(this).apply {
            hint = "Internal Actual Cost (₹)"
            inputType = 2
        }

        val customerPrice = EditText(this).apply {
            hint = "Customer Price (₹)"
            inputType = 2
        }

        val activation = EditText(this).apply {
            hint = "Activation Date"
        }

        val expiry = EditText(this).apply {
            hint = "Expiry Date"
        }

        listOf(
            entityIdInput, service, name, phone,
            stb, customerId, plan, actualCost,
            customerPrice, activation, expiry
        ).forEach { content.addView(it) }

        content.addView(button("Save Customer") {

            val entityId = database.entityId(
                entityIdInput.text.toString().trim()
            )

            val price = customerPrice.text.toString().toIntOrNull()

            if (
                entityId < 0 ||
                name.text.isBlank() ||
                phone.text.length != 10 ||
                price == null ||
                price < 0
            ) {
                Toast.makeText(
                    this,
                    "Please enter valid customer details",
                    Toast.LENGTH_LONG
                ).show()
                return@button
            }

            val actual = actualCost.text.toString().toIntOrNull() ?: 0

            database.addCustomer(
                entityId,
                service.selectedItem.toString(),
                name.text.toString(),
                phone.text.toString(),
                stb.text.toString(),
                customerId.text.toString(),
                plan.text.toString(),
                actual,
                price,
                activation.text.toString(),
                expiry.text.toString()
            )

            Toast.makeText(
                this,
                "Customer saved successfully",
                Toast.LENGTH_LONG
            ).show()

            showDashboard()
        })
    }

    private fun showCustomers() {

        setupPage(
            if (selectedService == "CABLE")
                "Cable TV Customers"
            else
                "Internet Customers"
        )

        val customers = database.customers(selectedService)

        if (customers.isEmpty()) {
            addCard("No customers available.")
        } else {
            customers.forEach {
                addCard(it)
            }
        }

        content.addView(button("Add Customer") {
            showAddCustomer()
        })

        content.addView(button("Back") {
            showDashboard()
        })
    }

    private fun showHelp() {

        setupPage("Help & Support")

        addSection("CATV MANAGER SUPPORT")

        addCard(
            """
            Support Contact

            Phone: 8605478047

            Email:
            aryantidake001@gmail.com

            Alternate Email:
            aryantidake@icloud.com

            Service:
            Cable TV & Internet Management
            """.trimIndent()
        )

        content.addView(button("Call Support") {
            startActivity(
                android.content.Intent(
                    android.content.Intent.ACTION_DIAL,
                    android.net.Uri.parse("tel:8605478047")
                )
            )
        })

        content.addView(button("Email Support") {
            startActivity(
                android.content.Intent(
                    android.content.Intent.ACTION_SENDTO,
                    android.net.Uri.parse(
                        "mailto:aryantidake001@gmail.com"
                    )
                )
            )
        })

        content.addView(button("Back") {
            showDashboard()
        })
    }
}

package com.catv.manager

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder

object WhatsAppHelper {

    fun sendBill(
        context: Context,
        mobileNumber: String,
        message: String
    ) {
        val number = mobileNumber
            .filter { it.isDigit() }
            .let {
                when {
                    it.length == 10 -> "91$it"
                    it.startsWith("91") && it.length == 12 -> it
                    else -> it
                }
            }

        if (number.length < 10) {
            Toast.makeText(
                context,
                "Invalid mobile number",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        try {
            val encodedMessage = URLEncoder.encode(message, "UTF-8")

            val url = "https://wa.me/$number?text=$encodedMessage"

            val intent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse(url)
            )

            context.startActivity(intent)

        } catch (e: Exception) {
            Toast.makeText(
                context,
                "Unable to open WhatsApp",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}

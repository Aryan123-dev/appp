package com.catv.manager

data class BillSummary(
    val previousArrears: Double,
    val currentBill: Double,
    val totalDue: Double,
    val totalPaid: Double,
    val remainingBalance: Double
)

object BillingHelper {

    fun calculateBill(
        previousArrears: Double,
        currentBill: Double,
        totalPaid: Double
    ): BillSummary {

        val arrears = previousArrears.coerceAtLeast(0.0)
        val bill = currentBill.coerceAtLeast(0.0)
        val paid = totalPaid.coerceAtLeast(0.0)

        val totalDue = arrears + bill
        val remaining = (totalDue - paid).coerceAtLeast(0.0)

        return BillSummary(
            previousArrears = arrears,
            currentBill = bill,
            totalDue = totalDue,
            totalPaid = paid.coerceAtMost(totalDue),
            remainingBalance = remaining
        )
    }

    // Allocate payment to the oldest outstanding bill first.
    fun allocatePayment(
        outstandingBills: List<MonthlyBill>,
        paymentAmount: Double
    ): List<MonthlyBill> {

        var remainingPayment = paymentAmount.coerceAtLeast(0.0)

        return outstandingBills
            .sortedBy { it.billingMonth }
            .map { bill ->

                val amountToApply =
                    minOf(bill.balance, remainingPayment)

                remainingPayment -= amountToApply

                bill.copy(
                    paidAmount = bill.paidAmount + amountToApply
                )
            }
    }

    fun formatAmount(amount: Double): String {
        return "₹%.2f".format(amount)
    }
}

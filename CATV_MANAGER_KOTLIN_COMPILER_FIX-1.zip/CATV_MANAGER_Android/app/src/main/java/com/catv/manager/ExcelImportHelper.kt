package com.catv.manager

import android.content.Context
import android.net.Uri
import android.text.Html
import java.io.BufferedReader
import java.io.InputStreamReader

data class ImportedCustomer(
    val stbNumber: String = "",
    val boxType: String = "",
    val name: String = "",
    val area: String = "",
    val mobile: String = "",
    val activationDate: String = "",
    val expiryDate: String = "",
    val rechargeAmount: String = "",
    val customerAmount: String = "",
    val category: String = ""
)

object ExcelImportHelper {

    fun readFile(
        context: Context,
        uri: Uri
    ): List<ImportedCustomer> {

        val input = context.contentResolver.openInputStream(uri)
            ?: return emptyList()

        val html = input.bufferedReader(Charsets.UTF_8).use {
            it.readText()
        }

        val rows = Regex(
            "<tr\\b[^>]*>(.*?)</tr>",
            RegexOption.IGNORE_CASE or RegexOption.DOT_MATCHES_ALL
        ).findAll(html)

        val result = mutableListOf<ImportedCustomer>()

        for (row in rows) {

            val cells = Regex(
                "<t[dh]\\b[^>]*>(.*?)</t[dh]>",
                RegexOption.IGNORE_CASE or RegexOption.DOT_MATCHES_ALL
            ).findAll(row.groupValues[1])
                .map { match ->
                    Html.fromHtml(
                        match.groupValues[1],
                        Html.FROM_HTML_MODE_LEGACY
                    ).toString().trim()
                }
                .toList()

            if (cells.size < 3) continue

            val normalized = cells.map {
                it.lowercase().replace(" ", "").trim()
            }

            // Skip header row
            if (normalized.any {
                it.contains("stbnumber") ||
                it.contains("subscribername")
            }) continue

            result.add(
                ImportedCustomer(
                    stbNumber = cells.getOrNull(0) ?: "",
                    boxType = cells.getOrNull(1) ?: "",
                    name = cells.getOrNull(2) ?: "",
                    area = cells.getOrNull(3) ?: "",
                    mobile = cells.getOrNull(4) ?: "",
                    activationDate = cells.getOrNull(5) ?: "",
                    expiryDate = cells.getOrNull(6) ?: "",
                    rechargeAmount = cells.getOrNull(7) ?: "",
                    customerAmount = cells.getOrNull(8) ?: "",
                    category = cells.getOrNull(9) ?: ""
                )
            )
        }

        return result
    }
}

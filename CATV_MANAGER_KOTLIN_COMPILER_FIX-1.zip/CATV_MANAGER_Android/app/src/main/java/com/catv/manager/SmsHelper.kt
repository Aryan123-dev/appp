package com.catv.manager

object SmsHelper {

    fun createBillMessage(
        customerName: String,
        billingMonth: String,
        customerPrice: Double,
        previousArrears: Double,
        todayPayment: Double,
        cumulativePaid: Double,
        remainingBalance: Double,
        dueDate: String
    ): String {

        return """
            Dear $customerName,

            Your CATV MANAGER bill details:

            Billing Month: $billingMonth
            Current Bill: ${money(customerPrice)}
            Previous Arrears: ${money(previousArrears)}
            Today's Payment: ${money(todayPayment)}
            Total Paid: ${money(cumulativePaid)}
            Remaining Balance: ${money(remainingBalance)}
            Due Date: $dueDate

            Please pay your outstanding amount before the due date.

            Thank you.
        """.trimIndent()
    }

    private fun money(amount: Double): String {
        return "Rs. %.2f".format(amount.coerceAtLeast(0.0))
    }
}

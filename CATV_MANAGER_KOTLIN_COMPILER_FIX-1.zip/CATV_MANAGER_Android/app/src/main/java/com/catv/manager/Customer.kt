package com.catv.manager

data class Customer(
    val id: Long,
    val entityId: Long,
    val serviceType: String,
    val name: String,
    val mobile: String,
    val stbId: String,
    val customerId: String,
    val planName: String,
    val actualCost: Double,
    val customerPrice: Double,
    val activationDate: String,
    val expiryDate: String,
    val status: String
)

data class OperatorEntity(
    val id: Long,
    val entityName: String,
    val operatorId: String
)

data class MonthlyBill(
    val id: Long,
    val customerId: Long,
    val billingMonth: String,
    val totalAmount: Double,
    val paidAmount: Double
) {
    val balance: Double
        get() = (totalAmount - paidAmount).coerceAtLeast(0.0)
}

data class Payment(
    val id: Long,
    val customerId: Long,
    val amount: Double,
    val paymentMethod: String,
    val paymentDate: String,
    val billingMonth: String
)

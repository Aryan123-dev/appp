package com.catv.manager

data class CustomerReport(
    val totalCustomers: Int,
    val activeCustomers: Int,
    val inactiveCustomers: Int,
    val expiredCustomers: Int,
    val cableCustomers: Int,
    val internetCustomers: Int,
    val totalMonthlyValue: Double
)

object ReportHelper {

    fun generateReport(
        customers: List<Customer>
    ): CustomerReport {

        val active = customers.count {
            it.status.equals("ACTIVE", ignoreCase = true)
        }

        val expired = customers.count {
            ExpiryHelper.checkExpiry(it.expiryDate).status ==
                ExpiryStatus.EXPIRED
        }

        val inactive = customers.size - active - expired

        val cable = customers.count {
            it.serviceType.equals("CABLE", ignoreCase = true)
        }

        val internet = customers.count {
            it.serviceType.equals("INTERNET", ignoreCase = true)
        }

        val monthlyValue = customers
            .filter {
                it.status.equals("ACTIVE", ignoreCase = true)
            }
            .sumOf { it.customerPrice }

        return CustomerReport(
            totalCustomers = customers.size,
            activeCustomers = active,
            inactiveCustomers = inactive.coerceAtLeast(0),
            expiredCustomers = expired,
            cableCustomers = cable,
            internetCustomers = internet,
            totalMonthlyValue = monthlyValue
        )
    }
}

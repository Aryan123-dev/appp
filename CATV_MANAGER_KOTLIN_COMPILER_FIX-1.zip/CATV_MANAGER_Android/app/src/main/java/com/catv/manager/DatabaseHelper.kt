package com.catv.manager

import android.content.Context

/**
 * Compatibility wrapper for older call sites. CATVDatabase is the single
 * authoritative SQLiteOpenHelper so the app cannot create competing schemas
 * for the same catv_manager.db file.
 */
@Deprecated("Use CATVDatabase; this wrapper shares the same database instance and schema.")
class DatabaseHelper(context: Context) : CATVDatabase(context)

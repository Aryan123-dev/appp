package com.catv.manager

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.time.temporal.ChronoUnit
import java.util.Locale

enum class ExpiryStatus {
    ACTIVE,
    EXPIRING_SOON,
    EXPIRED,
    INVALID_DATE
}

data class ExpiryInfo(
    val status: ExpiryStatus,
    val daysRemaining: Long?,
    val message: String
)

object ExpiryHelper {

    private val supportedFormats = listOf(
        DateTimeFormatter.ISO_LOCAL_DATE,
        DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH),
        DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH),
        DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.ENGLISH)
    )

    fun checkExpiry(
        expiryDate: String,
        warningDays: Long = 5
    ): ExpiryInfo {

        val date = parseDate(expiryDate)
            ?: return ExpiryInfo(
                ExpiryStatus.INVALID_DATE,
                null,
                "Invalid expiry date"
            )

        val today = LocalDate.now()
        val days = ChronoUnit.DAYS.between(today, date)

        return when {
            days < 0 -> ExpiryInfo(
                ExpiryStatus.EXPIRED,
                days,
                "Expired ${-days} day(s) ago"
            )

            days <= warningDays -> ExpiryInfo(
                ExpiryStatus.EXPIRING_SOON,
                days,
                if (days == 0L) {
                    "Expires today"
                } else {
                    "Expires in $days day(s)"
                }
            )

            else -> ExpiryInfo(
                ExpiryStatus.ACTIVE,
                days,
                "Active for $days more day(s)"
            )
        }
    }

    private fun parseDate(value: String): LocalDate? {
        for (formatter in supportedFormats) {
            try {
                return LocalDate.parse(value.trim(), formatter)
            } catch (_: DateTimeParseException) {
                // Try the next supported format.
            }
        }
        return null
    }
}

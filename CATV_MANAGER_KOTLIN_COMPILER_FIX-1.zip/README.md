# CATV MANAGER — Android starter project

This package is based on the existing Android/Kotlin project supplied for CATV MANAGER.

## Current project status

This is an **early Android prototype**, not a production-ready CATV + ISP ERP. It currently contains a basic native Android UI, local SQLite storage, operator entity/customer entry, cable/internet customer lists, and helper source files for billing, expiry, import, reports and messaging. Some helper modules are not yet connected to complete user workflows.

The full product requirements are in `docs/REQUIREMENTS_SOURCE.txt`.

## Confirmed product decisions

- Complete Operator + Admin edition.
- Android first; Windows client planned on the same shared backend/data model.
- Manual internet management plus planned MikroTik API integration.
- Hybrid offline + cloud architecture.
- Parent customer profile with separate Cable service ID and Internet service ID.
- Recharge validity: 30, 90, 180, 365 days and custom days.
- Staff can search and view **all customers** and record collections / issue receipts.
- Staff must not see UCN/MSO actual cost, internal margin, restricted expenses, admin settings, or other staff's private collection data.
- Only authorized Owner/Admin can edit or reverse financial transactions. Every such change must be audited.
- UI direction: navy/purple gradient, white rounded cards, clear search, dashboard cards and bottom navigation, following the user's supplied reference.

## Build APK with GitHub Actions

1. Upload the contents of this package to the root of a GitHub repository (keep `.github` and `CATV_MANAGER_Android` at the root).
2. Open **Actions** in GitHub.
3. Select **CATV MANAGER Android Build**.
4. Tap **Run workflow** and wait for the run to finish.
5. Open the completed run and download the `CATV-MANAGER-APK` artifact.

The workflow uses Java 17 and Gradle 8.9. The APK is produced by GitHub Actions; this package itself is source code, not an APK.

## Safe migration v2

The Android SQLite database now uses an additive version-1-to-version-2 migration. It keeps the existing `catv_manager.db` file and existing business tables/rows, adds stable local sync identifiers and a pending sync queue, and does not upload anything to Supabase yet. See `docs/SAFE_MIGRATION_V2.md` for the migration boundary and validation steps.

The GitHub Actions workflow now builds the checked-in `CATV_MANAGER_Android` project directly (rather than looking for a ZIP that is not present at the repository root).

## Important security note

The current prototype is local/offline and does not yet implement production authentication, role enforcement, cloud synchronization, secure credential storage, or a complete audit ledger. Do not use it for live customer financial records until those controls are implemented and tested. The staff permissions above are product requirements, not a claim that they are already enforced in this prototype.

## Planned implementation order

1. Foundation: database migrations, authentication, Owner/Admin/Staff roles, audit log.
2. Customer: parent profile, separate Cable/Internet service IDs, universal customer search.
3. Cable + Internet: STB/VC, ONU/PPPoE, plans, activation and expiry.
4. Recharge + ledger: 30/90/180/365/custom validity, advance/partial payments, arrears, receipts.
5. Staff collection: all-customer search, payment capture, receipt, own collection history, cash handover; no cost/profit visibility.
6. UCN import, complaints, inventory, reports and backup.
7. Backend/cloud sync, Windows client and authorized MikroTik/RADIUS/OLT integrations.

## Integration caveats

MikroTik, RADIUS, OLT, SMS, WhatsApp automation and payment gateway features need compatible equipment, authorized credentials, providers and configuration. They cannot be enabled by the app UI alone. UCN/MSO cost must never be included in customer-facing bills or messages.

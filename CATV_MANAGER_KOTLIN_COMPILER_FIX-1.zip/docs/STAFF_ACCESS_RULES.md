# Staff access rules — confirmed

## Staff may
- View and search all customers (not limited to an assigned area).
- Search by customer name, mobile number, Cable service ID/STB ID, Internet service ID/PPPoE ID and area.
- View customer contact details, service status, package/plan, activation/expiry and customer-facing outstanding amount.
- Record cash/UPI/bank collection and generate a receipt.
- View their own collection history and assigned operational tasks.

## Staff may not
- View UCN/MSO actual recharge cost, internal margin or profit.
- View restricted business expenses, salary details or another staff member's private collection history.
- Delete customers or payments, alter posted transactions, or change admin/security settings.

## Admin controls
- Create, disable and reset staff accounts.
- Review all collections, cash handovers and audit events.
- Correct or reverse a payment only through an auditable adjustment (never silently overwrite it).
- Configure module permissions and sensitive-field visibility.

## Security acceptance checks
- A staff account can search all customers but cannot open cost/margin fields.
- API responses must omit restricted fields for staff; hiding a UI label is not sufficient.
- Every payment records staff ID, timestamp, method, amount and unique receipt/reference.
- Duplicate payment submissions are rejected using an idempotency/reference key.
- Staff cannot edit/delete posted payments; an admin adjustment creates an audit entry.

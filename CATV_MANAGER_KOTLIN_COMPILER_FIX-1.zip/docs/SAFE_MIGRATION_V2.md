# CATV MANAGER — Safe SQLite Migration v2

## Scope of this change

This update prepares the existing local SQLite database for a later Supabase sync without replacing the database or deleting business records.

### Existing data retained

- `entities`
- `customers`
- `payments`
- `monthly_bills`
- `packages`

The SQLite database filename remains `catv_manager.db`. The database version advances from 1 to 2. The migration is additive only: it does not drop, rename, truncate, or recreate existing business tables and does not change their primary keys or existing business columns.

### Added metadata

Each existing business table receives:

- `sync_uuid`: stable cloud correlation identifier
- `sync_status`: `LOCAL` until a verified cloud sync occurs
- `updated_at`: local update marker

Two local support tables are added:

- `sync_queue`: pending upsert work, with unique table/UUID/operation key
- `sync_migration_log`: records the additive migration

Existing rows receive a generated `sync_uuid` and are queued as pending. Newly inserted entities, customers, and payments are queued as local pending changes.

## Important safety boundary

This release does **not** upload data to Supabase yet. It does not authenticate users, resolve organization ownership, or mark rows as cloud-synced. `LOCAL` means the record remains on the device. Do not treat the presence of a queue as proof of cloud backup.

Before enabling cloud sync, the next implementation must:

1. Confirm the live Supabase schema and organization mapping.
2. Add a durable mapping from local `entity_id` to Supabase `organizations.id`.
3. Define customer, service-plan, invoice, and payment field transformations.
4. Use idempotent upserts keyed by `sync_uuid` (or an explicit mapping table).
5. Resolve duplicate customer identities and conflicting edits without overwriting financial records.
6. Keep payment records append-only for staff; corrections/reversals must be audited and admin-only.
7. Enforce Supabase RLS so collection staff cannot read MSO costs, margins, or restricted expenses.
8. Test backup/restore and migration on a copy of real data before rollout.

## Existing schema warning

The repository contains a second, unused `DatabaseHelper` implementation that previously opened the same `catv_manager.db` filename with a different table definition. It is now a compatibility wrapper over `CATVDatabase`, so there is one authoritative schema helper.

## Verification

Build with the repository GitHub Actions workflow. Test the upgrade using a copy of a v1 database containing representative customers, bills, payments, packages, and entities. Compare row counts and primary keys before and after upgrade. Confirm all old rows remain and have `sync_status = 'LOCAL'` plus a non-empty `sync_uuid`.
